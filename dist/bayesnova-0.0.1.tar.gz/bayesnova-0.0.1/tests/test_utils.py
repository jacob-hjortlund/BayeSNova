import pytest

@pytest.mark.skip(reason="Not implemented yet")
def test_ensure_posdef():
    assert 1